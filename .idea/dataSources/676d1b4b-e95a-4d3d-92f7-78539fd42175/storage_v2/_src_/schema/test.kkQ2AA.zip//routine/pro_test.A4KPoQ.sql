create
    definer = root@localhost procedure pro_test(IN times int)
begin
declare var int default 0;
while var < times do
insert into a (begin) value(date_sub(now(),interval var year));
set var=var+1;
end while;
end;

