create
    definer = root@localhost procedure pro_test1(IN times int)
begin
declare var int default 0;
while var < times do
insert into a (begin) value(date_sub(now(),interval var month));
set var=var+1;
end while;
end;

