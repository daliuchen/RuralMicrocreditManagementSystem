create
    definer = root@localhost procedure pro_a(IN times int)
begin
declare var int default 0;
declare var1 int;
declare varYear int;
set unique_checks=0;
set autoCommit=0;
while var < times do
set varYear = floor(rand()*13);
set var1 = floor(rand()*2);
case var1
when 0 then
insert into t_contract(begin) values (date_add(now(),interval varYear month));
when 1 then
insert into t_contract(begin) values (date_sub(now(),interval varYear month));
end case;
set var = var+1;
end while;
set unique_checks=1;
set autoCommit=1;
end;

